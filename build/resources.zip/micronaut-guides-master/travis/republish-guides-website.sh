#!/bin/bash
set -e

if [ "$TRAVIS_BRANCH" = "master" ] && [ "$TRAVIS_PULL_REQUEST" = "false" ]; then
    export EXIT_STATUS=0

    git config --global user.name "$GIT_NAME"
    git config --global user.email "$GIT_EMAIL"
    git config --global credential.helper "store --file=~/.git-credentials"
    echo "https://$GH_TOKEN:@github.com" > ~/.git-credentials

    git clone https://${GH_TOKEN}@github.com/micronaut-projects/static-website.git -b master static-website --single-branch > /dev/null

    cd static-website

    chmod 777 gradlew

    ./gradlew guides:runShadow || EXIT_STATUS=$?

    if [[ $EXIT_STATUS -ne 0 ]]; then
        echo "Guides Website generation failed"
        exit $EXIT_STATUS
    fi

    cd ..

    rm -rf gh-pages

    git clone https://${GH_TOKEN}@github.com/micronaut-projects/micronaut-guides.git -b gh-pages gh-pages --single-branch > /dev/null

    cd gh-pages

    cp -r ../static-website/guides/build/site/* .

    if git diff --quiet; then
        echo "No changes in GUIDES Website"
    else
        git add *
        git commit -a -m "Updating guides site for Travis build: https://travis-ci.org/$TRAVIS_REPO_SLUG/builds/$TRAVIS_BUILD_ID"
        git push origin HEAD
    fi

    cd ..

    rm -rf static-website

    rm -rf gh-pages
fi

exit 0
